from fastapi import FastAPI, Form, Request, status
import uvicorn


app = FastAPI()

@app.get("/")
async def index(request: Request):
    print('Request for index page received')
    return "hello world"

# @app.get('/favicon.ico')
# async def favicon():
#     file_name = 'favicon.ico'
#     file_path = './static/' + file_name
#     return FileResponse(path=file_path, headers={'mimetype': 'image/vnd.microsoft.icon'})


if __name__ == '__main__':
    uvicorn.run('main:app', host='0.0.0.0', port=8000)