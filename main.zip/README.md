# online-shop-tcc


az webapp deploy --name online-shop-tcc --resource-group tcc --src-path .\app.zip